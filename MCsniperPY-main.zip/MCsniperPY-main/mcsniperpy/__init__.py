from mcsniperpy.sniper import Sniper
