# Todo

- [x] Account loading
- [x] Mojang account authentication
- [x] Snipe request
- [x] command line interface (the only way to run the sniper)
- [ ] Config system. Mostly done, but it still has some extra options that need to be added.
    - [ ] Webhook Color

> once all of that is done nonessential stuff can be worked on

## Nonessential todo

- [ ] Microsoft authentication
- [ ] plugin system (possibly)

## Other

- Bug fixes when they come up
